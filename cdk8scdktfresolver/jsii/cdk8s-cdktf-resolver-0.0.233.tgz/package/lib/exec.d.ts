export interface ExecSyncOptions {
    readonly cwd?: string;
    readonly env?: {
        [key: string]: string;
    };
}
export declare function execSync(command: string, options?: ExecSyncOptions): void;
