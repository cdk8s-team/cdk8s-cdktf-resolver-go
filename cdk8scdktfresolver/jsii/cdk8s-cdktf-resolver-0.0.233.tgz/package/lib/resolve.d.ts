import { IResolver, ResolutionContext } from 'cdk8s';
import { App } from 'cdktf';
export interface CdktfResolverProps {
    /**
     * The CDKTF App instance in which the outputs are deinfed in.
     */
    readonly app: App;
}
export declare class CdktfResolver implements IResolver {
    private readonly app;
    private _outputs;
    constructor(props: CdktfResolverProps);
    resolve(context: ResolutionContext): void;
    private fetchOutputValue;
    private fetchOutputs;
    private findOutput;
    private isAddressable;
}
